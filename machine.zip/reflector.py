from random import sample

class Reflector:
    def __init__(self):
        self.L1conexiones=[]
        self.L2conexiones=[]

    def GetL1Conexiones(self):
        return self.L1conexiones
    def GetL2Conexiones(self):
        return self.L2conexiones

    #n es la cantidad de caracteres
    def createReflector(self,Caracteres):
        n=len(Caracteres)
        removed = 0
        if n%2!=0:
            n-=1
            removed = Caracteres.pop(n)
        conexiones=sample(Caracteres,int(n/2))
        self.L1conexiones=conexiones
        for i in Caracteres:
            if i not in self.L1conexiones:
                self.L2conexiones.append(i)
        if removed != 0:
            self.L1conexiones.append(removed)
            self.L2conexiones.append(removed)
            Caracteres.append(removed)

        return self
    
    def reflect(self,Letra):
        if Letra in self.L1conexiones:
            return self.L2conexiones[self.L1conexiones.index(Letra)]
        else:
            return self.L1conexiones[self.L2conexiones.index(Letra)]
from machine import Enigma

chars = list("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzáéíóúñ ,.:0123456789!¡¿?'+-*=/%$#|()’“”<>_\\\"")
#msg = "aislamiento de estructuras para funciones específicas, sin interferencia externa, membrana plasmática, citoplasmática"
#msg = "El día de hoy hay permiso académico. Por tanto no se pueden realizar actividades de evaluación ni adelantar temas. Por esto les propongo que trabaje en sus tareas y nos vemos el próximo viernes. Por esta razón hoy no estaré presente en el salón de clases. Sin embargo estaré disponible via correo electrónico para resolver cualquier duda que tengan."
msg = "Can a father, his heart yearning with unspeakable tenderness over a child worthy of all the love he inspired, tell the story of that child wisely, fairly, profitably? Let me try: for to me it seems full of the sweetest lessons our Lord could bestow on parents and on children. Perhaps a ray of heavenly light from his life may fall pleasantly upon some path,--a somber and rugged path, perchance,--bringing assurance that in God’s time “the rough ways shall be made smooth,” and “light arise in the darkness."

enigma = Enigma(chars)
enigma.createMachine(7)

#print(chars, '\n')
#enigma.getData()

print(len(chars),'\n')
print("Mensaje original:",msg)
enigma.setPositions([1,1,1,1,1,1,1])
cmsg = enigma.code(msg)
print("\nMensaje encriptado:",cmsg)
enigma.setPositions([1,1,1,1,1,1,1])
cmsg2 = enigma.decode(cmsg)
print("\nMensaje desencriptado:",cmsg2)